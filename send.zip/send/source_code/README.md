To compile and run this code you need gcc and python install in you linux machine.
This code won't work on windows cause it's uses linux system command line .
To compile type "gcc main.c -lm" and to run " ./a.out "
After that follow the terminal instruction .
For better understanding open file "Project calcuations.xlsx".

For store the output of terminal in file use script...

       script filename_you_want_to_save
       than run the programm 
       and at the end use exit that will create the output file

