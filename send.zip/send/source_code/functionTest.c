#include"function.h"
int main()
{
	//struct four_complex_numbers quad = get_root_of_quartic_equation(7423.538334, -1937.269669, -40605172268.507228, -1769979459185018141.125000, 705230359053.054166);
	//struct four_complex_numbers quad = get_root_of_quartic_equation(-20,5,17,-29,87);
	//printf("%Lf %Lf %Lf %Lf %Lf %Lf %Lf %Lf\n",quad.first.real,quad.first.imaginary,quad.second.real,quad.second.imaginary,quad.third.real,quad.third.imaginary,quad.fourth.real,quad.fourth.imaginary);
	//struct  return_of_Bc result;
	//result = BC_arrangement(0.3,5726239892.0);
	//printf("%.15Lf %.15Lf",result.tank_volume_requared,result.no_of_unit_cell_required_to_design_the_tank);
	struct return_of_Fc result;
	FC_arrangement(0.3,5726239892.0);
}
